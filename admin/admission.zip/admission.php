<?php

include 'include/header.php';
include 'include/sidebar.php';
include 'include/top-right.php';

?>

<style>
    .admission-form{
        height:400px;
        background-color: red;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }
</style>


<div class="container">
    <div class="row">
        <div class="col-12 admission-form">
            <div class="row">
                <div class=""></div>
            </div>
        </div>
    </div>
</div>






<?php
	include 'include/footer.php';
?>
